import K
# Input: numpy vector alpha, with n entries
#        numpy matrix X of features, with n rows (samples), d columns (features)
#            X[i,r] is the r-th feature of the i-th sample
#        numpy vector y of labels, with n entries (samples)
#            y[i] is the label (+1 or -1) of the i-th sample
#        numpy vector z, with d entries
# Output: label (+1 or -1)
def run(alpha,X,y,z):
    label = -1.
    # Your code goes here
    return label
