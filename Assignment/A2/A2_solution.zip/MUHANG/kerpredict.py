import K
import numpy as np
# Input: numpy vector alpha, with n entries
#        numpy matrix X of features, with n rows (samples), d columns (features)
#            X[i,r] is the r-th feature of the i-th sample
#        numpy vector y of labels, with n entries (samples)
#            y[i] is the label (+1 or -1) of the i-th sample
#        numpy vector z, with d entries
# Output: label (+1 or -1)
def run(alpha,X,y,z):
    label = -1.
    # Your code goes here
    #Check exception
    #alpha
    if not isinstance(alpha, np.ndarray) or alpha.ndim != 1:
        raise ValueError('alpha must be a 1D numpy array')
    #X
    if not isinstance(X, np.ndarray) or X.ndim != 2:
        raise ValueError('X must be a 2D numpy array')
    #y
    if not isinstance(y, np.ndarray) or y.ndim != 1:
        raise ValueError('y must be a 1D numpy array')
    #z
    if not isinstance(z, np.ndarray) or z.ndim != 1:
        raise ValueError('z must be a 1D numpy array')

    n = len(alpha)
    if n != X.shape[0] or n != y.shape[0]:
        raise ValueError('Number of samples in alpha, X, and y must match')

    if X.shape[1] != z.shape[0]:
        raise ValueError('Feature dimensions of X and z must match')

    if not np.all(np.isin(y, [-1, 1])):
        raise ValueError('y must contain only -1 and 1')
    est=0
    for i in range(len(X)):
        est=est+alpha[i]*y[i]*K.run(X[i],z)
    if est>0:
        label=1.
    return label