import numpy as np
# Input: numpy vector w, with d entries
#        numpy vector z, with d entries
# Output: label (+1 or -1)
def run(w,z):
    label = -1.
    # Your code goes here
    return label
