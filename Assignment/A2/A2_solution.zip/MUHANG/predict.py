import numpy as np
# Input: numpy vector w, with d entries
#        numpy vector z, with d entries
# Output: label (+1 or -1)
def run(w,z):
    label = -1.
    # Your code goes here
    #Check exception
    #w
    if not isinstance(w, np.ndarray) or w.ndim != 1:
        raise ValueError('w must be a 1D numpy array')
    #z
    if not isinstance(z, np.ndarray) or z.ndim != 1:
        raise ValueError('z must be a 1D numpy array')
    #w & z
    if w.shape[0] != z.shape[0]:
        raise ValueError(
            'w and z must have the same number of elements')
    if w @ z>0:
        label=1.
    return label