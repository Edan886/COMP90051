import K
import numpy as np
# Input: number of iterations L
#        numpy matrix X of features, with n rows (samples), d columns (features)
#            X[i,r] is the r-th feature of the i-th sample
#        numpy vector y of labels, with n entries (samples)
#            y[i] is the label (+1 or -1) of the i-th sample
# Output: numpy vector alpha, with n entries
#         number of iterations that were actually executed (iter+1)
def run(L,X,y):
    n, d = X.shape
    alpha = np.zeros((n,))
    iter = 0
    # Your code goes here

    #Firstly, check if the shape and type of input can meet requirement
    #L 
    if not (isinstance(L, (int, float)) and L == int(L) and L>0):
        raise ValueError("L must be an integer or a float with no fractional part (e.g., 10.0, 11.0)")
    #X
    if np.ndim(X) != 2:
        raise ValueError("X must be a 2-dimensional array")
    #Y
    if not np.all(np.isin(y, [-1., 1.])):
        raise ValueError("y must contain only -1 or 1")
    if n != y.shape[0]:
        raise ValueError("The number of rows in X must match the length of y")
    if np.ndim(y) != 1:
        raise ValueError("y must be a 1-dimensional array")

    for iter in range(L):
        all_points_classified_correctly = True
        for i in range(n):
            temp=0
            for j in range(n):
                temp=temp+alpha[j]*y[j]*K.run(X[j],X[i])
            if (y[i]*temp)<=0:
                alpha[i]=alpha[i]+1
                all_points_classified_correctly = False
        if all_points_classified_correctly:
            break           
    return alpha, iter+1